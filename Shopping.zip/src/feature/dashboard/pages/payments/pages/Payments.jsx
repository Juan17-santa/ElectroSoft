import { useEffect, useState, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import paymentsService from "../services/paymentsService";
import ClientCreditCard from "../components/ClientCreditCard";
import SearchBar from "../../../components/ui/Searchbar";
import Pagination from "../../../components/ui/Pagination";
import { CreditCard } from "lucide-react";
import { generarReporteGeneral } from "../hooks/reportesPayments";
import ConfirmModal from "../../../components/ui/ConfirmModal";
import Alert from "../../../components/ui/Alert";

export default function Payments() {
    const navigate = useNavigate();
    const location = useLocation();

    const [clientes, setClientes] = useState([]);
    const [search, setSearch] = useState("");
    const [showReportModal, setShowReportModal] = useState(false);
    const [alert, setAlert] = useState()
    const [presentPage, setPresentPage] = useState(1);
    const recordsPerPage = 6;

    const cargarDatos = useCallback(() => {
        paymentsService.checkAndExpireOverdue();
        setClientes(paymentsService.getClientesConCupo());
    }, []);

    // Recarga al navegar a esta ruta
    useEffect(() => {
        cargarDatos();
    }, [location, cargarDatos]);

    // Recarga en tiempo real si algo cambia
    useEffect(() => {
        window.addEventListener("payments-updated", cargarDatos);
        return () => window.removeEventListener("payments-updated", cargarDatos);
    }, [cargarDatos]);

    const filtered = clientes.filter(c => {
        const q = search.toLowerCase();
        return (
            `${c.nombres} ${c.apellidos}`.toLowerCase().includes(q) ||
            String(c.documento).includes(q) ||
            String(c.tipoDocumento || "").toLowerCase().includes(q)
        );
    });

    const totalPages = Math.ceil(filtered.length / recordsPerPage);
    const currentRecords = filtered.slice(
        (presentPage - 1) * recordsPerPage,
        presentPage * recordsPerPage
    );

    return (
        <div className="bg-gray-100 p-6 rounded-2xl flex flex-col gap-6 w-full h-full shadow-inner overflow-y-auto">

            <p className="text-xl font-semibold">
                Control de créditos y abonos
            </p>

            <SearchBar
                searchTerm={search}
                onSearchChange={(e) => { setSearch(e.target.value); setPresentPage(1); }}
                placeholder="Buscar cliente..."
                showReportButton={true}
                onReportClick={() => setShowReportModal(true)}
                showCreateButton={false} // ESTA LÍNEA ES LA CLAVE
            />

            <div className="flex flex-col gap-3">
                {currentRecords.length === 0 ? (
                    <div className="bg-white rounded-2xl p-10 flex flex-col items-center gap-3 text-center shadow-md">
                        <CreditCard size={32} className="text-gray-300" />
                        <p className="text-gray-500 text-sm font-medium">
                            {search
                                ? "No se encontraron clientes con ese criterio."
                                : "No hay clientes con cupo de crédito asignado."}
                        </p>
                        {/* Mensaje orientativo — el cupo se asigna desde Clientes */}
                        {!search && (
                            <p className="text-xs text-gray-400">
                                Los cupos se asignan desde el módulo de{" "}
                                <span className="font-semibold text-yellow-500">Clientes</span>
                                {" "}cuando las compras superan $1.000.000.
                            </p>
                        )}
                    </div>
                ) : (
                    currentRecords.map(cliente => (
                        <ClientCreditCard
                            key={cliente.id}
                            cliente={cliente}
                            onClick={() => navigate(`/dashboard/payments/client/${cliente.documento}`)}
                        />
                    ))
                )}
            </div>

            <div className="flex justify-end mt-auto pt-4">
                <Pagination
                    currentPage={presentPage}
                    totalPages={totalPages}
                    onPageChange={(page) => setPresentPage(page)}
                />
            </div>
            {showReportModal && (
                <ConfirmModal
                    type="info"
                    title="Generar reporte"
                    message="Selecciona el rango de fechas para el reporte"
                    showDateFilter={true}
                    onCancel={() => setShowReportModal(false)}
                    onConfirm={({ fechaInicio, fechaFin }) => {
                        try {
                            generarReporteGeneral(clientes, fechaInicio, fechaFin);

                            setAlert({
                                type: "success",
                                message: "El reporte se generó correctamente"
                            });

                        } catch (error) {
                            setAlert({
                                type: "error",
                                message: "Hubo un error al generar el reporte"
                            });
                        }

                        setShowReportModal(false);
                    }}
                />
            )}
            {alert && (
                <Alert
                    type={alert.type}
                    message={alert.message}
                    onClose={() => setAlert(null)}
                />
            )}
        </div>

    );
}