const KEY = "products";

export const ServicesProducts = {

    // Obtener todos los productos
    get() {
        const data = localStorage.getItem(KEY);
        return data ? JSON.parse(data) : [];
    },

    // Obtener producto por ID
    getById(id) {
        const productos = this.get();
        return productos.find(prod => String(prod.id) === String(id));
    },

    // Crear producto
    create(producto) {

        const productos = this.get();

        const nuevoProducto = {
            id: Date.now(),
            nombre: producto.nombre || "",
            categoriaId: producto.categoriaId || "",
            precio: Number(producto.precio) || 0,
            stock: Number(producto.stock) || 0,
            tipoStock: producto.tipoStock || "unidad",
            serial: producto.serial || "",
            garantia: producto.garantia || "",
            caracteristicas: producto.caracteristicas || [],
            estado: true,
            createdAt: new Date().toISOString()
        };

        const nuevosProductos = [...productos, nuevoProducto];

        localStorage.setItem(KEY, JSON.stringify(nuevosProductos));

        return nuevoProducto;
    },

    // Actualizar producto
    update(productoActualizado) {

        const productos = this.get();

        const nuevosProductos = productos.map(prod =>
            prod.id === productoActualizado.id
                ? {
                    ...prod,
                    ...productoActualizado,
                    precio: Number(productoActualizado.precio),
                    stock: Number(productoActualizado.stock)
                }
                : prod
        );

        localStorage.setItem(KEY, JSON.stringify(nuevosProductos));

        return productoActualizado;
    },

    /**
     * Registra una entrada de inventario generada por una compra.
     * Devuelve el movimiento para que el modulo de compras lo guarde como auditoria.
     */
    registerPurchaseEntry({ productId, cantidad, precioVenta, usarPrecioSugerido = false, fecha = new Date().toISOString() }) {

        const productoActual = this.getById(productId);
        if (!productoActual) return null;

        const cantidadEntrada = Number(cantidad) || 0;
        const stockAnterior = Number(productoActual.stock) || 0;
        const stockNuevo = stockAnterior + cantidadEntrada;
        const precioAnterior = Number(productoActual.precio) || 0;
        const precioVentaUnitario = Number(precioVenta) || 0;

        const wacExacto = stockAnterior > 0
            ? (stockAnterior * precioAnterior + cantidadEntrada * precioVentaUnitario) / stockNuevo
            : precioVentaUnitario;

        const costoPromedioNuevo = Math.ceil(wacExacto / 100) * 100;
        const precioNuevo = usarPrecioSugerido ? precioVentaUnitario : costoPromedioNuevo;

        this.update({
            ...productoActual,
            stock: stockNuevo,
            precio: precioNuevo,
            costoPromedio: costoPromedioNuevo,
        });

        return {
            productoId: productoActual.id,
            productoNombre: productoActual.nombre,
            cantidad: cantidadEntrada,
            cantidadAnterior: stockAnterior,
            cantidadNueva: stockNuevo,
            precioVentaUnitario,
            precioAnterior,
            costoPromedioNuevo,
            precioAplicado: precioNuevo,
            tipo: "ENTRADA",
            fecha,
        };
    },

    /**
     * Revierte una entrada de inventario previamente registrada por compras.
     * No revierte precios, porque el comportamiento actual del modulo de compras
     * solo resta stock al anular.
     */
    revertPurchaseEntry(movimiento) {

        const producto = this.getById(movimiento.productoId);
        if (!producto) {
            return {
                producto: null,
                stockCalculado: null,
                stockNuevo: null,
                advertencia: null,
            };
        }

        const cantidad = Number(movimiento.cantidad) || 0;
        const stockActual = Number(producto.stock) || 0;
        const stockCalculado = stockActual - cantidad;
        const stockNuevo = Math.max(0, stockCalculado);

        this.update({
            ...producto,
            stock: stockNuevo,
        });

        return {
            producto,
            stockCalculado,
            stockNuevo,
            advertencia: stockCalculado < 0
                ? `"${movimiento.productoNombre}": el stock actual (${stockActual}) es menor a las unidades ingresadas en la compra (${cantidad}). Se ajusto a 0, pero puede haber inconsistencia en el inventario.`
                : null,
        };
    },

    // Eliminar producto
    delete(id) {

        const productos = this.get();

        const nuevosProductos = productos.filter(prod => prod.id !== id);

        localStorage.setItem(KEY, JSON.stringify(nuevosProductos));

        return nuevosProductos;
    },

    // Activar / Desactivar producto
    toggleEstado(id) {

        const productos = this.get();

        const nuevosProductos = productos.map(prod =>
            prod.id === id
                ? { ...prod, estado: !prod.estado }
                : prod
        );

        localStorage.setItem(KEY, JSON.stringify(nuevosProductos));

        return nuevosProductos;
    }
};
