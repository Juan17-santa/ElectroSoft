import { useState, useEffect } from "react";
import { formatCOP } from "../helpers/shoppingHelpers";
import { ServicesProducts } from "../../products/services/ServicesProducts";
import { ServicesShopping } from "../services/ServicesShopping";

/**
 * Hook centralizado para el módulo de compras.
 * Maneja: carga, guardado, anulación, inventario y búsqueda.
 *
 * Reglas de negocio aplicadas:
 *  - Al guardar una compra se incrementa el stock de cada producto
 *    y se actualiza su precio de venta en el catálogo (precioVenta → precio).
 *  - La anulación solo está disponible dentro de las 48 h posteriores
 *    al registro de la compra (fechaCreacion), no a la fecha de factura.
 *  - Al anular se revierte el inventario; si el stock actual es menor
 *    al que se había ingresado, se trunca a 0 y se registra una advertencia.
 */
export function useShopping() {
    const [compras, setCompras] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    // ─── Carga inicial ─────────────────────────────────────────────────────────
    useEffect(() => {
        // #5 / #6: Se usa ServicesShopping en lugar de leer localStorage directo.
        // #2: Se elimina el bloque de "backward compatibility" que sobreescribía
        //     fechaCreacion con fechaCompra, confundiendo dos conceptos distintos:
        //     la fecha de la factura del proveedor ≠ la fecha de registro en el sistema.
        const comprasGuardadas = ServicesShopping.get().map((compra) => ({
            ...compra,
            // Garantizar que campos opcionales siempre existan
            fechaCreacion: compra.fechaCreacion || new Date(0).toISOString(),
            movimientosInventario: compra.movimientosInventario || [],
            infoAnulacion: compra.infoAnulacion || null,
        }));
        setCompras(comprasGuardadas);
    }, []);

    // ─── Filtrado ──────────────────────────────────────────────────────────────
    const comprasFiltradas = compras.filter((c) => {
        const term = searchTerm.toLowerCase().trim();
        if (!term) return true;
        return (
            c.proveedor.toLowerCase().includes(term) ||
            c.numeroFactura.toLowerCase().includes(term) ||
            c.fechaCompra.toLowerCase().includes(term) ||
            c.estado.toLowerCase().includes(term)
        );
    });

    // ─── Acciones ──────────────────────────────────────────────────────────────

    /**
     * Guarda una nueva compra, actualiza el inventario y el catálogo de precios.
     *
     * @param {Object} params
     * @param {string}   params.numeroFactura
     * @param {string}   params.fechaFactura    - Fecha formateada (DD/MM/YYYY)
     * @param {string}   params.proveedor       - Nombre del proveedor (display)
     * @param {number}   params.proveedorId     - ID del proveedor (referencia)
     * @param {number}   params.total           - Total de la compra (con IVA, base coste)
     * @param {Array}    params.productos        - Lista de productos con { id, nombre, cantidad, precio, costeProducto, precioVenta, subtotal }
     */
    const guardarCompra = ({ numeroFactura, fechaFactura, proveedor, proveedorId, total, productos }) => {
        const fechaCreacion = new Date().toISOString();
        const movimientos = [];

        productos.forEach((producto) => {
            const productoActual = ServicesProducts.getById(producto.id);

            if (productoActual) {
                const stockAnterior = productoActual.stock;
                const stockNuevo = stockAnterior + producto.cantidad;

                // #4 + punto 16: Al comprar se actualiza el stock Y el precio de venta
                // del catálogo (precioVenta registrado en la compra → precio del producto).
                // Esto mantiene el catálogo sincronizado con el último precio de compra.
                ServicesProducts.update({
                    ...productoActual,
                    stock: stockNuevo,
                    precio: producto.precioVenta,
                });

                movimientos.push({
                    productoId:       producto.id,
                    productoNombre:   producto.nombre,
                    cantidad:         producto.cantidad,
                    cantidadAnterior: stockAnterior,
                    cantidadNueva:    stockNuevo,
                    precioAnterior:   productoActual.precio,
                    precioNuevo:      producto.precioVenta,
                    tipo:             "ENTRADA",
                    fecha:            fechaCreacion,
                });
            }
        });

        const nuevaCompra = {
            id: Date.now(),
            numeroFactura,
            fechaCompra:          fechaFactura,
            proveedor,            // Nombre — para búsqueda y display
            proveedorId,          // #7: ID del proveedor para trazabilidad
            iva:                  formatCOP(Math.round(total * (0.19 / 1.19))),
            total:                formatCOP(Math.round(total)),
            estado:               "Activo",
            productos,
            fechaCreacion,        // Momento exacto del registro en el sistema
            movimientosInventario: movimientos,
            infoAnulacion:        null,
        };

        // #5: Persistencia a través de la capa de servicio
        ServicesShopping.create(nuevaCompra);
        setCompras((prev) => [...prev, nuevaCompra]);
    };

    /**
     * Valida si una compra puede anularse según las reglas de negocio.
     * La ventana de anulación se calcula desde fechaCreacion (registro en el sistema),
     * NO desde la fecha de la factura del proveedor. (#2)
     *
     * @param {Object} compra
     * @returns {{ puedeAnularse: boolean, razon: string, horasRestantes: number }}
     */
    const validarAnulacion = (compra) => {
        if (compra.estado !== "Activo") {
            return {
                puedeAnularse: false,
                razon:         "Solo se pueden anular compras con estado 'Activo'.",
                horasRestantes: 0,
            };
        }

        const fechaCreacion    = new Date(compra.fechaCreacion);
        const ahora            = new Date();
        const diferenciaHoras  = (ahora - fechaCreacion) / (1000 * 60 * 60);
        const horasRestantes   = Math.max(0, 48 - Math.floor(diferenciaHoras));

        if (diferenciaHoras >= 48) {
            return {
                puedeAnularse: false,
                razon:         "Han pasado más de 48 h desde el registro. No se puede anular.",
                horasRestantes: 0,
            };
        }

        return { puedeAnularse: true, razon: "", horasRestantes };
    };

    /**
     * Anula una compra y revierte el inventario.
     * #14: Si el stock actual es menor al que se ingresó en la compra (p. ej. ya se
     * vendió parte del lote), el stock se trunca a 0 y se devuelve una advertencia
     * en lugar de quedar en negativo silenciosamente.
     *
     * @param {number} id               - ID de la compra a anular
     * @param {Object} infoAnulacion    - { motivo, fechaAnulacion, usuario }
     * @returns {{ advertencias: string[] }} - Lista de advertencias de inventario
     */
    const handleAnular = (id, infoAnulacion) => {
        const compraAAnular = compras.find((c) => c.id === id);
        const advertencias = [];

        if (compraAAnular?.movimientosInventario?.length) {
            compraAAnular.movimientosInventario.forEach((mov) => {
                const producto = ServicesProducts.getById(mov.productoId);
                if (!producto) return;

                const stockCalculado = producto.stock - mov.cantidad;

                // #14: Detectar y advertir sobre stock que sería negativo
                if (stockCalculado < 0) {
                    advertencias.push(
                        `"${mov.productoNombre}": el stock actual (${producto.stock}) es menor ` +
                        `a las unidades ingresadas en la compra (${mov.cantidad}). ` +
                        `Se ajustó a 0, pero puede haber inconsistencia en el inventario.`
                    );
                }

                ServicesProducts.update({
                    ...producto,
                    stock: Math.max(0, stockCalculado),
                });
            });
        }

        const updated = compras.map((c) =>
            c.id === id
                ? {
                    ...c,
                    estado: "Anulada",
                    infoAnulacion: {
                        motivo:         infoAnulacion.motivo,
                        fechaAnulacion: infoAnulacion.fechaAnulacion,
                        usuario:        infoAnulacion.usuario,
                    },
                }
                : c
        );

        // #5: Persistencia a través de la capa de servicio
        ServicesShopping.saveAll(updated);
        setCompras(updated);

        return { advertencias };
    };

    /** Busca una compra por su id */
    const getCompraById = (id) =>
        compras.find((c) => String(c.id) === String(id)) || null;

    return {
        compras,
        comprasFiltradas,
        searchTerm,
        setSearchTerm,
        guardarCompra,
        handleAnular,
        getCompraById,
        validarAnulacion,
    };
}